Creative Portion:

1. What I did:

I added sounds to the app. When a user feeds a pet an eating sound is played. When a user plays with a pet a positive/reward sound is played.


2. How I did it:

I downloaded sound effect files from the internet and stored them in a folder called "Sound Effects." I added this folder to my project. I also imported AVFoundation. 

Then, I created two functions "eatingSound" and "happySound." These functions get the file path with the sound audio and then using AVFoundation to play the sound.

I added the sound functions to the "play" and "feed" functions, so whenever the pet is played with or fed the corresponding sound plays.


3. Why I did it:

I added these features because it makes the app more fun. It adds another sense, sound, which enhances the user's experience. A user can now imagine the pet being fed or played with.