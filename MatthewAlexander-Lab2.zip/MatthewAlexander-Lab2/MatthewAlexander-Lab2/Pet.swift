//
//  Pet.swift
//  MatthewAlexander-Lab2
//
//  Created by Matthew Alexander on 9/25/21.
//

import Foundation
import AVFoundation

struct Pet {
    var happiness = 0.0
    var foodLevel = 0.0
    var numPlayed = 0
    var numFed = 0
    
    var audio: AVAudioPlayer?
    
    var species: Species
    
    enum Species {
        case dog
        case cat
        case bird
        case bunny
        case fish
    }
    
    mutating func play() {
        if foodLevel > 0 {
            foodLevel -= 0.1
            numPlayed += 1
            happySound()
            if happiness < 1 {
                happiness += 0.1
            }
        }
    }
    
    mutating func feed() {
        numFed += 1
        if foodLevel < 1 {
            foodLevel += 0.1
        }
        eatingSound()
    }
    
    mutating func happySound() {
        guard let url = Bundle.main.url(forResource: "happy.wav", withExtension: nil) else {return}
        // https://stackoverflow.com/questions/32036146/how-to-play-a-sound-using-swift
        do {
            audio = try AVAudioPlayer(contentsOf: url)
            audio?.play()
        }
        catch {
        }
    }
    
    mutating func eatingSound() {
        guard let url = Bundle.main.url(forResource: "eating.wav", withExtension: nil) else {return}
        // https://stackoverflow.com/questions/32036146/how-to-play-a-sound-using-swift
        do {
            audio = try AVAudioPlayer(contentsOf: url)
            audio?.play()
        }
        catch {
        }
    }
    
}
