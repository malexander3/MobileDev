//
//  ViewController.swift
//  MatthewAlexander-Lab2
//
//  Created by Matthew Alexander on 9/21/21.
//

import UIKit

class ViewController: UIViewController {

    var pets = ["dog": Pet(species: .dog), "cat": Pet(species: .cat), "bird": Pet(species: .bird), "bunny": Pet(species: .bunny), "fish": Pet(species: .fish)]
    var currentPet = "bird"
    
    @IBOutlet weak var background: UIView!
    @IBOutlet weak var happinessBar: DisplayView!
    @IBOutlet weak var foodBar: DisplayView!
    @IBOutlet weak var playedLabel: UILabel!
    @IBOutlet weak var fedLabel: UILabel!
    @IBOutlet weak var petImage: UIImageView!
    
    @IBAction func dogPressed(_ sender: Any) {
        currentPet = "dog"
        displayColor()
        displayValues()
    }
    
    @IBAction func catPressed(_ sender: Any) {
        currentPet = "cat"
        displayColor()
        displayValues()
    }
    
    @IBAction func birdPressed(_ sender: Any) {
        currentPet = "bird"
        displayColor()
        displayValues()
    }
    
    @IBAction func bunnyPressed(_ sender: Any) {
        currentPet = "bunny"
        displayColor()
        displayValues()
    }
    
    @IBAction func fishPressed(_ sender: Any) {
        currentPet = "fish"
        displayColor()
        displayValues()
    }
    
    @IBAction func play(_ sender: Any) {
        pets[currentPet]?.play()
        displayColor()
        displayValues()
    }
    
    @IBAction func feed(_ sender: Any) {
        pets[currentPet]?.feed()
        displayColor()
        displayValues()
    }
    
    func displayColor() {
        switch pets[currentPet]?.species {
        case .dog:
            petImage.image = UIImage(named: currentPet)
            let customRed = UIColor(red: 0.92, green: 0.36, blue: 0.34, alpha: 1)
            background.backgroundColor = customRed
            happinessBar.color = customRed
            foodBar.color = customRed
        case .cat:
            petImage.image = UIImage(named: currentPet)
            let customBlue = UIColor(red: 0.34, green: 0.51, blue: 0.95, alpha: 1)
            background.backgroundColor = customBlue
            happinessBar.color = customBlue
            foodBar.color = customBlue
        case .bird:
            petImage.image = UIImage(named: currentPet)
            let customYellow = UIColor(red: 0.98, green: 0.87, blue: 0.40, alpha: 1)
            background.backgroundColor = customYellow
            happinessBar.color = customYellow
            foodBar.color = customYellow
        case .bunny:
            petImage.image = UIImage(named: currentPet)
            let customGreen = UIColor(red: 0.43, green: 0.91, blue: 0.44, alpha: 1)
            background.backgroundColor = customGreen
            happinessBar.color = customGreen
            foodBar.color = customGreen
        case .fish:
            petImage.image = UIImage(named: currentPet)
            let customPurple = UIColor(red: 0.86, green: 0.63, blue: 0.98, alpha: 1)
            background.backgroundColor = customPurple
            happinessBar.color = customPurple
            foodBar.color = customPurple
        case .none: break
        }
    }
        
    func displayValues() {
        happinessBar.animateValue(to: CGFloat(pets[currentPet]?.happiness ?? 0))
        playedLabel.text = "played: \(pets[currentPet]?.numPlayed ?? 0)"
        foodBar.animateValue(to: CGFloat(pets[currentPet]?.foodLevel ?? 0))
        fedLabel.text = "fed: \(pets[currentPet]?.numFed ?? 0)"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

