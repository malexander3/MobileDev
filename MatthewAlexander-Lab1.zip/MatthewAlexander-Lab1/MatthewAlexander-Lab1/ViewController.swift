//
//  ViewController.swift
//  MatthewAlexander-Lab1
//
//  Created by Matthew Alexander on 9/13/21.
//

import UIKit

class ViewController: UIViewController {
    
    let cart = ShoppingCart()
    var cartIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var button: UIButton!
    
    @IBAction func addToCart(_ sender: Any) {
        if cartIndex < 5 {
            displayCart()
            cartIndex+=1
        }
        if cartIndex >= 5 {
            button.isEnabled = false
            button.setTitle("Cart Full", for: .disabled)
            button.setTitleColor(.red, for: .disabled)
        }
        clearCalculator()
        displayCalc()
    }
    
    func displayCalc() {
        let item = cart.get(item: cartIndex)
        if (errorExists() || tooBig(i: item)) {
            finalPrice.text = "n/a"
        }
        else {
            let price = item.getFinalPrice()
            finalPrice.text = "$\(String(format: "%.2f", price))"
        }
    }
    
    func displayCart() {
        if cartIndex == 0 {
            items.text = ""
            prices.text = ""
        }
        let item = cart.get(item: cartIndex)
        items.text! += "\(item.getName())\n"
        totalPrice.text = "Total: $\(String(format: "%.2f", cart.getTotalPrice()))"
        if (errorExists() || tooBig(i: item)) {
            prices.text! += "n/a\n"
        }
        else {
            prices.text! += "$\(String(format: "%.2f", item.getFinalPrice()))\n"
        }
    }
    
    func clearCalculator() {
        name.text = ""
        origPrice.text = ""
        discount.text = ""
        salesTax.text = ""
    }
    
    @IBAction func editName(_ sender: Any) {
        let item = cart.get(item: cartIndex)
        let newName = String(name.text!)
        item.setName(n: newName)
        displayCalc()
    }
    
    @IBAction func editOrigPrice(_ sender: Any) {
        let item = cart.get(item: cartIndex)
        if let newPrice = Double(origPrice.text!) {
            item.setOrigPrice(p: newPrice)
        }
        else {
            item.setOrigPrice(p: -1)
        }
        displayCalc()
    }
    
    @IBAction func editDiscount(_ sender: Any) {
        let item = cart.get(item: cartIndex)
        if let newDiscount = Double(discount.text!) {
            item.setDiscount(d: newDiscount)
        }
        else {
            item.setDiscount(d: -1)
        }
        displayCalc()
    }
    
    @IBAction func editSalesTax(_ sender: Any) {
        let item = cart.get(item: cartIndex)
        if let newSalesTax = Double(salesTax.text!) {
            item.setSalesTax(s: newSalesTax)
        }
        else {
            item.setSalesTax(s: -1)
        }
        displayCalc()
    }
    
    func errorExists() -> Bool {
        let item = cart.get(item: cartIndex)
        if item.getOrigPrice() < 0 || item.getDiscount() < 0 || item.getSalesTax() < 0 {
            return true
        }
        else {
            return false
        }
    }
        
    func tooBig(i: Item) -> Bool {
        if i.getFinalPrice() >= 1000000000000000 {
            return true
        }
        else {
            return false
        }
    }
    
    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var origPrice:UITextField!
    
    @IBOutlet weak var discount: UITextField!
    
    @IBOutlet weak var salesTax: UITextField!

    @IBOutlet weak var finalPrice: UILabel!
    
    @IBOutlet weak var items: UILabel!
    
    @IBOutlet weak var prices: UILabel!
    
    @IBOutlet weak var totalPrice: UILabel!
}

