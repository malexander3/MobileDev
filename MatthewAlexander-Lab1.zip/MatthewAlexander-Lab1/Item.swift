//
//  Item.swift
//  MatthewAlexander-Lab1
//
//  Created by Matthew Alexander on 9/13/21.
//

import Foundation

class Item {
    
    private var name: String
    private var origPrice: Double
    private var discount: Double
    private var salesTax: Double
    
    func getFinalPrice() -> Double {
        if getOrigPrice() < 0 || getDiscount() < 0 || getSalesTax() < 0  {
            return 0
        }
        let price = origPrice * (1 - discount/100) * (1 + salesTax/100)
        let roundedPrice = round(price*100)/100
        return roundedPrice
    }
    
    func setName(n: String) {
        name = n
    }
    
    func setOrigPrice(p: Double) {
        origPrice = p
    }
    
    func setDiscount(d: Double) {
        discount = d
    }
    
    func setSalesTax(s: Double) {
        salesTax = s
    }
    
    func getName() -> String {
        return name
    }
    
    func getOrigPrice() -> Double {
        return origPrice
    }
    
    func getDiscount() -> Double {
        return discount
    }
    
    func getSalesTax() -> Double {
        return salesTax
    }
    
    init() {
        self.name = ""
        self.origPrice = -1
        self.discount = -1
        self.salesTax = -1
    }
}
