1. I added a shopping cart. Users can add items to the shopping cart and find the total price of all the items in their cart. Users can add up to 5 items.

On the screen, users see the name of each item in the cart and each item's price. The total price of all the items is also displayed.


2. I implemented the features above by creating a ShoppingCart class, which contains an array of Item objects. 

I also created an "add to cart" button, so the user can add items to their cart. 
The "add to cart" button turns red when the users has added too many items (max of 5). 

I then used labels to display the cart's information (items, prices, and total price).


3. I implemented these features, so that a user can determine how much everything in their shopping cart will cost. In a real world scenario, people want to determine the total cost of all their items.

Based on the total cost, a user may then decide to substitute or remove an item.
