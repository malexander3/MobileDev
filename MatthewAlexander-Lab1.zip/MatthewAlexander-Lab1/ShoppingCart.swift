//
//  ShoppingCart.swift
//  MatthewAlexander-Lab1
//
//  Created by Matthew Alexander on 9/15/21.
//

import Foundation

class ShoppingCart {
    var cart: [Item]
    
    func getTotalPrice() -> Double {
        var total = 0.0
        for item in cart {
            total += item.getFinalPrice()
        }
        return total
    }
    
    func add(item: Item) {
        cart.append(item)
    }
    
    func get(item index: Int) -> Item {
        cart[index]
    }
    
    init() {
        cart = [Item]()
        for _ in 0 ... 5 {
            let i = Item()
            add(item: i)
        }

    }
}
