//
//  ViewController.swift
//  MatthewAlexander-Lab3
//
//  Created by Matthew Alexander on 10/5/21.
//
import AVFoundation
import UIKit

class ViewController: UIViewController, UIGestureRecognizerDelegate {
    
    var userOptions = UserOptions()
    var color: UIColor = .systemRed
    var selectedShape: Shape?
    var audio: AVAudioPlayer?
    
    @IBOutlet weak var canvas: DrawingView!
    
    @IBOutlet var pincher: UIPinchGestureRecognizer!
    @IBOutlet var rotater: UIRotationGestureRecognizer!
    
    @IBOutlet weak var modeControls: UISegmentedControl!
    @IBOutlet weak var shapeControls: UISegmentedControl!
    
    @IBOutlet weak var redButton: UIButton!
    @IBOutlet weak var orangeButton: UIButton!
    @IBOutlet weak var yellowButton: UIButton!
    @IBOutlet weak var greenButton: UIButton!
    @IBOutlet weak var blueButton: UIButton!
    @IBOutlet weak var purpleButton: UIButton!
    
    @IBAction func newMode(_ sender: Any) {
        if modeControls.selectedSegmentIndex == 0 {
            userOptions.mode = .draw
        }
        else if modeControls.selectedSegmentIndex == 1 {
            userOptions.mode = .move
        }
        else {
            userOptions.mode = .erase
        }
    }
    
    
    @IBAction func newShapeType(_ sender: Any) {
        if shapeControls.selectedSegmentIndex == 0 {
            userOptions.shape = .square
        }
        else if shapeControls.selectedSegmentIndex == 1 {
            userOptions.shape = .circle
        }
        else {
            userOptions.shape = .triangle
        }
    }
    
    @IBAction func clear(_ sender: Any) {
        canvas.items = []
        deleteSound()
    }
    
    func transparentColorButtons() {
        (redButton.alpha, orangeButton.alpha, yellowButton.alpha, greenButton.alpha, blueButton.alpha, purpleButton.alpha)
            = (0.7, 0.7, 0.7, 0.7, 0.7, 0.7)
    }
    
    @IBAction func selectRed(_ sender: Any) {
        color = .systemRed
        transparentColorButtons()
        redButton.alpha = 1
    }
    
    @IBAction func selectOrange(_ sender: Any) {
        color = .systemOrange
        transparentColorButtons()
        orangeButton.alpha = 1
    }

    @IBAction func selectYellow(_ sender: Any) {
        color = .systemYellow
        transparentColorButtons()
        yellowButton.alpha = 1
    }
    
    @IBAction func selectGreen(_ sender: Any) {
        color = .systemGreen
        transparentColorButtons()
        greenButton.alpha = 1
    }
    
    @IBAction func selectBlue(_ sender: Any) {
        color = .systemBlue
        transparentColorButtons()
        blueButton.alpha = 1
    }
    
    @IBAction func selectPurple(_ sender: Any) {
        color = .systemPurple
        transparentColorButtons()
        purpleButton.alpha = 1
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard touches.count == 1,
            let touchPoint = touches.first?.location(in: canvas)
        else { return }
        switch userOptions.mode {
        case .draw:
            addShape(type: userOptions.shape, origin: touchPoint, color: color)
        case .move:
            selectedShape = canvas.itemAtLocation(touchPoint) as? Shape
        case .erase:
            let shape = canvas.itemAtLocation(touchPoint)
            eraseShape(shape: shape)
        }
    }
    
    func addShape(type: UserOptions.ShapeType, origin: CGPoint, color: UIColor) {
        switch userOptions.shape {
        case .square:
            canvas.items.append(Square(origin: origin, color: color))
        case .circle:
            canvas.items.append(Circle(origin: origin, color: color))
        case .triangle:
            canvas.items.append(Triangle(origin: origin, color: color))
        }
    }
    
    func eraseShape(shape: DrawingItem?) {
        // line below from Piazza @237:
        if let index = canvas.items.firstIndex(where: {$0 === shape}) {
            canvas.items.remove(at: index)
            canvas.setNeedsDisplay()
            deleteSound()
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if userOptions.mode == .move {
            guard touches.count == 1,
                  let touchPoint = touches.first?.location(in: canvas)
            else { return }
            selectedShape?.moveOrigin(newOrigin: touchPoint)
            canvas.setNeedsDisplay()
        }
    }
        
    // move calculations to model (MVC)
    @IBAction func pinch(_ sender: Any) {
        if userOptions.mode == .move {
            let point = pincher.location( in: canvas)
            let drawingItem = canvas.itemAtLocation(point)
            if let shape = drawingItem as? Shape {
                let newSize = shape.size * pincher.scale
                shape.changeSize(size: newSize)
                pincher.scale = 1.0
            }
            canvas.setNeedsDisplay()
        }
    }
    
    @IBAction func rotate(_ sender: Any) {
        if userOptions.mode == .move {
            let point = rotater.location( in: canvas)
            let drawingItem = canvas.itemAtLocation(point)
            let change = rotater.rotation
            if let shape = drawingItem as? Shape {
                shape.path.spin(radians: change)
                shape.radians += change
                rotater.rotation = 0.0
            }
            canvas.setNeedsDisplay()
        }
    }

    func deleteSound() {
        // source: https://stackoverflow.com/questions/32036146/how-to-play-a-sound-using-swift
        guard let url = Bundle.main.url(forResource: "trash.wav", withExtension: nil) else {return}
        do {
            audio = try AVAudioPlayer(contentsOf: url)
            audio?.play()
        }
        catch {
        }
    }
    
     func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {true}
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        pincher.delegate = self
        rotater.delegate = self
        transparentColorButtons()
        redButton.alpha = 1
    }
}

