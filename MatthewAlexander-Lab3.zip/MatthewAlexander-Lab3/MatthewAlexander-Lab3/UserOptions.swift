//
//  UserOptions.swift
//  MatthewAlexander-Lab3
//
//  Created by Matthew Alexander on 10/8/21.
//

import Foundation

struct UserOptions {
    var mode: Mode = .draw
    var shape: ShapeType = .square
    
    enum Mode
    {
        case draw
        case move
        case erase
    }

    enum ShapeType
    {
        case square
        case circle
        case triangle
    }
}
