//
//  Shape.swift
//  CSE 438S Lab 3
//
//  Created by Michael Ginn on 5/31/21.
//

import UIKit

/**
 YOU SHOULD MODIFY THIS FILE.
 
 Feel free to implement it however you want, adding properties, methods, etc. Your different shapes might be subclasses of this class, or you could store information in this class about which type of shape it is. Remember that you are partially graded based on object-oriented design. You may ask TAs for an assessment of your implementation.
 */

/// A `DrawingItem` that draws some shape to the screen.
extension UIBezierPath {
    func spin(radians: CGFloat) {
        let center = CGPoint(x: bounds.midX, y: bounds.midY)
        var transform = CGAffineTransform.identity
        transform = transform.translatedBy(x: center.x, y: center.y)
        transform = transform.rotated(by: radians)
        transform = transform.translatedBy(x: -center.x, y: -center.y)
        self.apply(transform)
    }
}

class Shape: DrawingItem {
    var origin: CGPoint
    var color: UIColor
    var size: CGFloat = 40.0
    var radians: CGFloat = 0.0
    var path: UIBezierPath = UIBezierPath()
    
    public required init(origin: CGPoint, color: UIColor){
        self.origin = origin
        self.color = color
    }
    
    func draw() {
        color.setFill()
        path.fill()
    }
    
    func contains(point: CGPoint) -> Bool {
        return path.contains(point)
    }
    
    func changeSize(size: CGFloat) {
    }
    
    func moveOrigin(newOrigin: CGPoint) {
    }
}
