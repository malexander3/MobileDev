//
//  Circle.swift
//  MatthewAlexander-Lab3
//
//  Created by Matthew Alexander on 10/5/21.
//

import UIKit

class Circle: Shape {
    
    required init(origin: CGPoint, color: UIColor) {
        super.init(origin: origin, color: color)
        path = UIBezierPath(arcCenter: origin, radius: size, startAngle: 0, endAngle: CGFloat(Float.pi * 2), clockwise: true)
    }
    
    override func changeSize(size: CGFloat) {
        self.size = size
        path = UIBezierPath(arcCenter: origin, radius: size, startAngle: 0, endAngle: CGFloat(Float.pi * 2), clockwise: true)
        path.spin(radians: radians)
    }
    
    override func moveOrigin(newOrigin: CGPoint) {
        origin = newOrigin
        path = UIBezierPath(arcCenter: origin, radius: size, startAngle: 0, endAngle: CGFloat(Float.pi * 2), clockwise: true)
    }
    
}
