//
//  Square.swift
//  MatthewAlexander-Lab3
//
//  Created by Matthew Alexander on 10/6/21.
//

import UIKit

class Square: Shape {
    
    required init(origin: CGPoint, color: UIColor) {
        super.init(origin: origin, color: color)
        self.origin = CGPoint(x: origin.x - size, y: origin.y - size)
        let rect = CGRect(x: self.origin.x, y: self.origin.y, width: 2*size, height: 2*size)
        path = UIBezierPath(rect: rect)
    }
    
    override func changeSize(size: CGFloat) {
        self.size = size
        let rect = CGRect(x: origin.x, y: origin.y, width: 2*size, height: 2*size)
        path = UIBezierPath(rect: rect)
        path.spin(radians: radians)
    }
    
    override func moveOrigin(newOrigin: CGPoint) {
        origin = CGPoint(x: newOrigin.x - size, y: newOrigin.y - size)
        let rect = CGRect(x: origin.x, y: origin.y, width: 2*size, height: 2*size)
        path = UIBezierPath(rect: rect)
        path.spin(radians: radians)
    }
    
}
