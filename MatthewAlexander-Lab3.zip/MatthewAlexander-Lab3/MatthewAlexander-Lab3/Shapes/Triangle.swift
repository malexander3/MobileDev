//
//  Triangle.swift
//  MatthewAlexander-Lab3
//
//  Created by Matthew Alexander on 10/8/21.
//

import UIKit

class Triangle: Shape {
    
    required init(origin: CGPoint, color: UIColor) {
        super.init(origin: origin, color: color)
        self.origin = CGPoint(x: origin.x - size, y: origin.y - size)
        let rect = CGRect(x: self.origin.x, y: self.origin.y, width: 2*size, height: 2*size)
        path = trianglePath(rect: rect)
    }
    
    func trianglePath(rect: CGRect) -> UIBezierPath {
        // source: https://www.hackingwithswift.com/books/ios-swiftui/paths-vs-shapes-in-swiftui
        let path = UIBezierPath()
        path.move(to: CGPoint(x: rect.midX, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.minX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.midX, y: rect.maxY))
        return path
    }
    
    override func changeSize(size: CGFloat) {
        self.size = size
        let rect = CGRect(x: origin.x, y: origin.y, width: 2*size, height: 2*size)
        path = trianglePath(rect: rect)
        path.spin(radians: radians)
    }
    
    override func moveOrigin(newOrigin: CGPoint) {
        origin = CGPoint(x: newOrigin.x - size, y: newOrigin.y - size)
        let rect = CGRect(x: origin.x, y: origin.y, width: 2*size, height: 2*size)
        path = trianglePath(rect: rect)
        path.spin(radians: radians)
    }
    
}
