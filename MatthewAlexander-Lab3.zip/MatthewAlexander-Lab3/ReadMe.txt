Read me
1. I added sound effects. Whenever the user either deletes shapes or clears the whole screen, he or she hears a whoosh sound effect.

2. I found an online sound effect file. I added it to my project. Then, using AVFoundation, I can play the audio. I call the sound effect whenever the user deletes or clears.

3. I added it because it adds another dimension to the app. It also makes it clear when shapes or close together that a shape is being deleted.