//
//  DetailedViewController.swift
//  MatthewAlexander-Lab4
//
//  Created by Matthew Alexander on 11/1/21.
//

import UIKit

class DetailedViewController: UIViewController {

    var poster: UIImage?
    var movie: Movie?
    let button = UIButton(type: .system)

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.backgroundColor = .white
        let imageView = UIImageView(frame: CGRect(x: view.frame.midX - 100, y: 120, width: 200, height: 300))
        imageView.image = poster
        view.addSubview(imageView)
        let release = UILabel(frame: CGRect(x: 0, y: 445, width: view.frame.width, height: 30))
        release.text = "Released: " + "\(movie?.release_date ?? "n/a")"
        release.textAlignment = .center
        view.addSubview(release)
        let score = UILabel(frame: CGRect(x: 0, y: 485, width: view.frame.width, height: 30))
        score.text = "Score: n/a"
        if (movie?.vote_average != nil) {
            let num = (Int)(movie!.vote_average * 10)
            score.text = "Score: \(num)/100"
        }
        score.textAlignment = .center
        view.addSubview(score)
        let description = UILabel(frame: CGRect(x: 20, y: 490, width: view.frame.width - 40, height: 200))
        description.text = "Description: " + "\(movie?.overview ?? "n/a")"
        description.numberOfLines = 6
        view.addSubview(description)
        self.navigationItem.title = movie?.title
        button.frame = CGRect(x: 95, y: 660, width: 200, height: 30)
        button.setTitle("Add to Favorites", for: UIControl.State.normal)
        button.addTarget(self, action: #selector(favorite), for: .touchUpInside)
        view.addSubview(button)
    }
    
    @IBAction func favorite(sender: UIButton!) {
        print("Added to Favorites")
    }

}
