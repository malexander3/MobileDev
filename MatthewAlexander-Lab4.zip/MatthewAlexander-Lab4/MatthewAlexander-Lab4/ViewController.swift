//
//  ViewController.swift
//  MatthewAlexander-Lab4
//
//  Created by Matthew Alexander on 10/24/21.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UISearchBarDelegate {

    var apiResults: APIResults?
    var imageCache: [UIImage] = []
    var search = " "
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var searchBar: UISearchBar!
    var spinner = UIActivityIndicatorView(style: .large)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setUp()
        /*self.spinner.startAnimating()
        DispatchQueue.global(qos: .userInitiated).async {
            self.fetchDataforCollectionView()
            self.cacheImages()
            DispatchQueue.main.async {
                self.collectionView.reloadData()
                self.spinner.stopAnimating()
            }
        }*/
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        var numItems = apiResults?.total_results ?? 0
        if (numItems > 20) {
            numItems = 20
        }
        return numItems
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "myCell", for: indexPath)
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 115, height: 172.5))
        if (indexPath.row >= imageCache.count) {
            imageView.backgroundColor = .white
            cell.contentView.addSubview(imageView)
            return cell
        }
        else {
            imageView.image = imageCache[indexPath.row]
            cell.contentView.addSubview(imageView)
            // Source: https://stackoverflow.com/questions/27059284/set-text-in-uicollectionviewcell
            let label = UILabel(frame: CGRect(x: 0, y: 122.5, width: 115, height: 50))
            label.text = apiResults?.results[indexPath.row].title
            label.font = UIFont(name: "Helvetica Neue Bold", size: 14)
            label.textColor = .white
            label.textAlignment = .center
            label.numberOfLines = 2
            label.backgroundColor = UIColor(displayP3Red: 0.1, green: 0.1, blue: 0.1, alpha: 0.7)
            cell.contentView.addSubview(label)
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if (indexPath.row < imageCache.count) {
            let detailedViewController = DetailedViewController()
            detailedViewController.movie = apiResults?.results[indexPath.row]
            detailedViewController.poster = imageCache[indexPath.row]
            navigationController?.pushViewController(detailedViewController, animated: true)
        }
    }
    
    func setUp() {
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "myCell")
        searchBar.delegate = self
        spinner.hidesWhenStopped = true
        spinner.color = .blue
        spinner.center = CGPoint(x: 195, y: 265)
        view.addSubview(spinner)
        spinner.layer.zPosition = 1
    }
    
    func fetchDataforCollectionView() {
        guard let url = URL(string: "https://api.themoviedb.org/3/search/movie?api_key=bf2a4b92581753808a9d865d2e113ea3&query=" + search) else {return}
        let data = try? Data(contentsOf: url)
        if data != nil {
            apiResults = try? JSONDecoder().decode(APIResults.self, from: data!)
        }
    }
    
    func cacheImages() {
        imageCache = []
        guard let movies = apiResults?.results else {return}
        for movie in movies {
            if let poster = movie.poster_path {
                if let url = URL(string: "https://image.tmdb.org/t/p/original" + poster) {
                    let data = try? Data(contentsOf: url)
                    if data != nil {
                        let image = UIImage(data: data!)
                        if image != nil {
                            imageCache.append(image!)
                        }
                    }
                }
            }
            else {
                let image = UIImage(named: "defaultImage")!
                imageCache.append(image)
            }
        }
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
    {
        search = searchBar.text ?? " "
        self.spinner.startAnimating()
        DispatchQueue.global(qos: .userInitiated).async {
            self.fetchDataforCollectionView()
            self.cacheImages()
            DispatchQueue.main.async {
                self.collectionView.reloadData()
                self.spinner.stopAnimating()
            }
        }
    }
}
